/*---------------------*/
/*---- Insert CSS -----*/
var head = document.getElementsByTagName('head')[0];
var link = document.createElement('link');
link.rel = 'stylesheet';
link.type = 'text/css';
link.href = browser.runtime.getURL("canvas.css");
link.media = 'all';
head.appendChild(link);


let pixels = [];
let canvas = document.createElement('canvas');
let context;
let mImgData;

let button = document.createElement('button');
button.classList.add('bored')
button.innerHTML="MIR ISCH LW DUSO?";
document.body.appendChild(button);

let download = document.createElement('button');
download.classList.add('download')
download.innerHTML="WETTSCH PIC?";
document.body.appendChild(download);

download.addEventListener('click', function (e) {
  
  canvas.toBlob(function(blob){ 
    //console.log(blob);
    var link = document.createElement("a");
    link.download = Date.now()+"_image.png";
    link.href = URL.createObjectURL(blob);
    link.click();
  })
 
})

button.addEventListener('click', function (e) {
  browser.runtime.sendMessage('takeScreenshot');
 download.style.display= "block"
})

browser.runtime.onMessage.addListener((request) => {

  //console.log('got screensot')
  screenshot = request.data;

  bitmap = new Image();
  bitmap.src = request.data;
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.position = "fixed";
  canvas.style.top = "0px";
  canvas.style.zIndex = 200;
  canvas.classList.add("p5Canvas")
  context = canvas.getContext('2d');

  bitmap.onload = function () {
    // take_screenshot();
    // setTimeout(startSorting, 2000); // Delay the start of sorting by 20 seconds
   /* setTimeout(function () {
      take_screenshot();
      startSorting();
    }, 2000); // Delay the start of sorting by 20 seconds
    */

    take_screenshot();
    startSorting();
  };

});

function take_screenshot() {
  context.drawImage(bitmap, 0, 0, window.innerWidth, window.innerHeight);
  document.body.appendChild(canvas);
}

function startSorting() {
  // take_screenshot(); das war falsch
  loadPixels();

  // Loop 1000 times to speed up the animation.
  for (let i = 0; i < 10000; i++) {
    sortPixels();
  }

  context.putImageData(mImgData, 0, 0);

  requestAnimationFrame(startSorting);
}

// Rest of the code...



function sortPixels() {

  // Get a random pixel.
  const x = Math.floor(Math.random()*canvas.width);
  const y = Math.floor(Math.random()* (canvas.height - 1));
  
  
  const px1 = (y * canvas.width + x)*4;
  // const px2 = ((y + 1) * canvas.width + x)*4;
  // const px2 = ((y + 1) * canvas.width + x)*4; // trz to chnage the +1
  // const px2 = ((y) * canvas.width + (x + 1))*4; // trz to chnage the +1
  const px2 = ((y + 1) * canvas.width + (x + 1))*4; // trz to chnage the +1

  // Get the color of the random pixel.
  const redOne = pixels[px1];
  const greenOne = pixels[px1+1];
  const blueOne = pixels[px1+2];

  // Get the color of the pixel below the first one.
  const redTwo = pixels[px2];
  const greenTwo = pixels[px2+1];
  const blueTwo = pixels[px2+2];

  // Get the total R+G+B of both colors.
  const totalOne = redOne + greenOne + blueOne;
  const totalTwo = redTwo + greenTwo + blueTwo;

  // If the first total is less than the second total, swap the pixels.
  // This causes darker colors to fall to the bottom,
  // and light pixels to rise to the top.
  if (totalOne < totalTwo) {
    //console.log('swap')
    pixels[px1] = redTwo;
    pixels[px1+1]= greenTwo;
    pixels[px1+2] = blueTwo;
    pixels[px2] = redOne;
    pixels[px2+1]= greenOne
    pixels[px2+2] = blueOne;

  }
  // alpha channel 0 - 255
  // let random = Math.random * 255
  pixels[px1 + 3] = 255


}

function loadPixels() {
 
/*
  let srcIndex = 0, dstIndex = 0, curPixelNum = 0;
  let pixelsArray = new Array(canvas.width * canvas.height);
  
  for (curPixelNum = 0; curPixelNum < canvas.width * canvas.height; curPixelNum++) {
    pixelsArray[dstIndex] = new Array(3);
    pixelsArray[dstIndex][0] = pixels[srcIndex]; // r
    pixelsArray[dstIndex][1] = pixels[srcIndex + 1];   // g
    pixelsArray[dstIndex][2] = pixels[srcIndex + 2];   // b
    

    dstIndex += 1;
    srcIndex += 3;
  }*/

  mImgData = context.getImageData(0, 0, canvas.width, canvas.height);
  pixels = mImgData.data;
 
  
  
}